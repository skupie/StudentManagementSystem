<x-guest-layout>
    <div class="max-w-5xl mx-auto py-8 px-4">
        @livewire('model-tests.public-results')
    </div>
</x-guest-layout>
