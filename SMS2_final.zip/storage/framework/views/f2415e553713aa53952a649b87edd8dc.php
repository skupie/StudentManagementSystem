<?php
    $formatter = fn ($value) => '৳ ' . number_format($value, 2);
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <?php if($user->isAdmin()): ?>
                
                <div class="grid md:grid-cols-4 gap-4">
                    <div class="p-4 bg-white rounded-lg shadow">
                        <p class="text-sm text-gray-500">Income (This Month)</p>
                        <p class="text-2xl font-bold text-green-600"><?php echo e($formatter($financialSnapshot['income'])); ?></p>
                    </div>
                    <div class="p-4 bg-white rounded-lg shadow">
                        <p class="text-sm text-gray-500">Expenses (This Month)</p>
                        <p class="text-2xl font-bold text-red-600"><?php echo e($formatter($financialSnapshot['expenses'])); ?></p>
                    </div>
                    <div class="p-4 bg-white rounded-lg shadow">
                        <p class="text-sm text-gray-500">Net Income</p>
                        <p class="text-2xl font-bold"><?php echo e($formatter($financialSnapshot['net'])); ?></p>
                    </div>
                    <div class="p-4 bg-white rounded-lg shadow <?php echo e($financialSnapshot['thresholdExceeded'] ? 'border border-red-400' : ''); ?>">
                        <p class="text-sm text-gray-500">Outstanding Dues</p>
                        <p class="text-2xl font-bold text-amber-600"><?php echo e($formatter($financialSnapshot['outstanding'])); ?></p>
                        <?php if($financialSnapshot['thresholdExceeded']): ?>
                            <p class="text-xs text-red-600 mt-2">Alert: outstanding dues exceeded the configured threshold.</p>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="bg-white rounded-lg shadow p-4 space-y-4">
                    <div class="grid md:grid-cols-4 gap-4">
                        <div>
                            <p class="text-sm text-gray-500">Total Students</p>
                            <p class="text-2xl font-bold"><?php echo e($studentCounts['total']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Active</p>
                            <p class="text-2xl font-bold text-green-600"><?php echo e($studentCounts['active']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Inactive</p>
                            <p class="text-2xl font-bold text-gray-600"><?php echo e($studentCounts['inactive']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Passed</p>
                            <p class="text-2xl font-bold text-indigo-600"><?php echo e($studentCounts['passed']); ?></p>
                        </div>
                    </div>
                    <div class="grid md:grid-cols-<?php echo e(max(1, $classDistribution->count())); ?> gap-4">
                        <?php $__currentLoopData = $classDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-3 bg-gray-50 rounded border">
                                <p class="text-xs text-gray-500"><?php echo e(\App\Support\AcademyOptions::classLabel($class)); ?></p>
                                <p class="text-lg font-semibold"><?php echo e($count); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div class="grid md:grid-cols-2 gap-4">
                    <div class="bg-white rounded-lg shadow p-4">
                        <h3 class="font-semibold text-gray-800">Attendance Today</h3>
                        <div class="space-y-2">
                            <?php $__empty_1 = true; $__currentLoopData = $attendanceToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class => $statuses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="flex justify-between text-sm border-b pb-1">
                                    <span><?php echo e(\App\Support\AcademyOptions::classLabel($class)); ?></span>
                                    <span>
                                        P: <?php echo e($statuses->firstWhere('status', 'present')->total ?? 0); ?>,
                                        A: <?php echo e($statuses->firstWhere('status', 'absent')->total ?? 0); ?>

                                    </span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-sm text-gray-500">No attendance data for today.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-4">
                        <h3 class="font-semibold text-gray-800">Exam Performance (Last 7 days)</h3>
                        <div class="space-y-2">
                            <?php $__empty_1 = true; $__currentLoopData = $examHealth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="flex justify-between text-sm border-b pb-1">
                                    <span><?php echo e(\App\Support\AcademyOptions::classLabel($item->class_level)); ?> / <?php echo e(\App\Support\AcademyOptions::sectionLabel($item->section)); ?></span>
                                    <span><?php echo e(number_format($item->average, 1)); ?>%</span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-sm text-gray-500">No marks recorded in the last week.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="grid md:grid-cols-2 gap-4">
                    <div class="bg-white rounded-lg shadow p-4 space-y-3">
                        <h3 class="font-semibold text-gray-800">Recent Activity</h3>
                        <div>
                            <p class="text-xs text-gray-500">New Students</p>
                            <ul class="text-sm space-y-1">
                                <?php $__currentLoopData = $recentActivities['students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($item->name); ?> <span class="text-xs text-gray-500">— <?php echo e(optional($item->created_at)->diffForHumans()); ?></span></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500">Payments</p>
                            <ul class="text-sm space-y-1">
                                <?php $__currentLoopData = $recentActivities['payments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($payment->student->name ?? 'Student'); ?> paid <?php echo e($formatter($payment->amount)); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-4 space-y-3">
                        <div>
                            <p class="text-xs text-gray-500">Absence Notes</p>
                            <ul class="text-sm space-y-1">
                                <?php $__currentLoopData = $recentActivities['notes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($note->student->name ?? 'Student'); ?> — <?php echo e($note->category); ?> (<?php echo e(optional($note->note_date)->format('d M')); ?>)</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500">Expenses</p>
                            <ul class="text-sm space-y-1">
                                <?php $__currentLoopData = $recentActivities['expenses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($expense->category); ?> — <?php echo e($formatter($expense->amount)); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500">New Instructors</p>
                            <ul class="text-sm space-y-1">
                                <?php $__currentLoopData = $recentActivities['instructors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($instructor->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>

                
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.inactive-student-alert', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2858402771-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                
                <div class="bg-white rounded-lg shadow p-4">
                    <h3 class="font-semibold text-gray-800 mb-3">Quick Actions</h3>
                    <div class="flex flex-wrap gap-3">
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('students.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('students.index')).'\'']); ?>Add Student <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('ledger.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('ledger.index')).'\'']); ?>Record Expense <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('users.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('users.index')).'\'']); ?>Create Team Member <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('due-list.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('due-list.index')).'\'']); ?>Download Due List <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div class="bg-white rounded-lg shadow p-4 space-y-3">
                    <h3 class="font-semibold text-gray-800">Invoice Update Alerts</h3>
                    <p class="text-xs text-gray-500">Recent edits to fee invoices</p>
                    <ul class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $invoiceUpdateAlerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="py-2 flex items-start justify-between gap-3">
                                <div>
                                    <p class="text-sm text-red-600 font-semibold"><?php echo e($alert->description ?? 'Invoice updated'); ?></p>
                                    <p class="text-xs text-gray-500">
                                        By: <?php echo e($alert->user->name ?? 'System'); ?> • <?php echo e(optional($alert->created_at)->diffForHumans()); ?>

                                    </p>
                                </div>
                                <?php if(!empty($alert->model_id)): ?>
                                    <span class="inline-flex px-2 py-1 rounded-full text-[11px] bg-indigo-100 text-indigo-700">Invoice #<?php echo e($alert->model_id); ?></span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="py-2 text-sm text-gray-500">No recent invoice edits.</li>
                        <?php endif; ?>
                    </ul>
                    <div class="text-xs text-gray-500">Full history available in Audit Log.</div>
                </div>

                
                <div class="bg-white rounded-lg shadow p-4 space-y-3">
                    <h3 class="font-semibold text-gray-800">Notifications</h3>
                    <div>
                        <p class="text-xs text-gray-500 mb-1">Students with dues older than 2 months</p>
                        <ul class="text-sm space-y-1">
                            <?php $__empty_1 = true; $__currentLoopData = $notifications['overdueStudents']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><?php echo e($student->name); ?> – <?php echo e($formatter($student->feeInvoices->sum(fn($invoice) => max(0, $invoice->amount_due - $invoice->amount_paid)))); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-gray-500 text-sm">No overdue students 🎉</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500 mb-1">Instructors pending weekly exam updates</p>
                        <ul class="text-sm space-y-1">
                            <?php $__empty_1 = true; $__currentLoopData = $notifications['pendingInstructors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><?php echo e($name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-gray-500 text-sm">All instructors submitted this week.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            <?php elseif($user->isAssistant()): ?>
                <?php
                    $hscOneCount = $classDistribution['hsc_1'] ?? 0;
                    $hscTwoCount = $classDistribution['hsc_2'] ?? 0;
                ?>
                <div class="grid md:grid-cols-4 gap-4">
                    <div class="p-4 bg-white rounded-lg shadow">
                        <p class="text-sm text-gray-500">Total Students</p>
                        <p class="text-2xl font-bold text-gray-800"><?php echo e($studentCounts['total']); ?></p>
                    </div>
                    <div class="p-4 bg-white rounded-lg shadow">
                        <p class="text-sm text-gray-500">Active</p>
                        <p class="text-2xl font-bold text-green-600"><?php echo e($studentCounts['active']); ?></p>
                    </div>
                    <div class="p-4 bg-white rounded-lg shadow">
                        <p class="text-sm text-gray-500">Inactive</p>
                        <p class="text-2xl font-bold text-gray-600"><?php echo e($studentCounts['inactive']); ?></p>
                    </div>
                    <div class="p-4 bg-white rounded-lg shadow">
                        <p class="text-sm text-gray-500">Passed</p>
                        <p class="text-2xl font-bold text-indigo-600"><?php echo e($studentCounts['passed']); ?></p>
                    </div>
                </div>

                <div class="grid md:grid-cols-2 gap-4">
                    <div class="p-4 bg-blue-50 border border-blue-100 rounded-lg shadow-sm">
                        <p class="text-sm text-gray-600">HSC 1st Year</p>
                        <p class="text-2xl font-bold text-blue-700 mt-1"><?php echo e($hscOneCount); ?></p>
                    </div>
                    <div class="p-4 bg-indigo-50 border border-indigo-100 rounded-lg shadow-sm">
                        <p class="text-sm text-gray-600">HSC 2nd Year</p>
                        <p class="text-2xl font-bold text-indigo-700 mt-1"><?php echo e($hscTwoCount); ?></p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-4">
                    <h3 class="font-semibold text-gray-800">Exam Performance Snapshot</h3>
                    <div class="space-y-2 mt-3">
                        <?php $__empty_1 = true; $__currentLoopData = $examHealth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex justify-between text-sm border-b pb-1">
                                <span><?php echo e(\App\Support\AcademyOptions::classLabel($item->class_level)); ?> / <?php echo e(\App\Support\AcademyOptions::sectionLabel($item->section)); ?></span>
                                <span><?php echo e(number_format($item->average, 1)); ?>%</span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-gray-500">No weekly exam data recorded recently.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-4">
                    <h3 class="font-semibold text-gray-800">Attendance Snapshot (Today)</h3>
                    <div class="space-y-2 mt-3">
                        <?php $__empty_1 = true; $__currentLoopData = $attendanceToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class => $statuses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex justify-between text-sm border-b pb-1">
                                <span><?php echo e(\App\Support\AcademyOptions::classLabel($class)); ?></span>
                                <span>P: <?php echo e($statuses->firstWhere('status', 'present')->total ?? 0); ?>, A: <?php echo e($statuses->firstWhere('status', 'absent')->total ?? 0); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-gray-500">No attendance records for today yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-4">
                    <h3 class="font-semibold text-gray-800 mb-3">Quick Actions</h3>
                    <div class="flex flex-wrap gap-3">
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('attendance.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('attendance.index')).'\'']); ?>Record Attendance <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('holidays.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('holidays.index')).'\'']); ?>Manage Holidays <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('weekly-exams.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('weekly-exams.index')).'\'']); ?>Weekly Exams <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('leaderboard.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('leaderboard.index')).'\'']); ?>Leaderboard <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('reports.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('reports.index')).'\'']); ?>Reports <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-4 space-y-3">
                    <h3 class="font-semibold text-gray-800">Notifications</h3>
                    <div>
                        <p class="text-xs text-gray-500 mb-1">Instructors pending weekly exam updates</p>
                        <ul class="text-sm space-y-1">
                            <?php $__empty_1 = true; $__currentLoopData = $notifications['pendingInstructors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><?php echo e($name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-gray-500 text-sm">All instructors submitted this week.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            <?php else: ?>
                
                <div class="grid md:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $classPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-4 bg-white rounded-lg shadow">
                            <p class="text-sm text-gray-500"><?php echo e(\App\Support\AcademyOptions::classLabel($item->class_level)); ?> / <?php echo e(\App\Support\AcademyOptions::sectionLabel($item->section)); ?></p>
                            <p class="text-2xl font-bold"><?php echo e(number_format($item->average, 1)); ?>%</p>
                            <p class="text-xs text-gray-500 mt-1">Average score this month</p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="grid md:grid-cols-2 gap-4">
                    <div class="bg-white rounded-lg shadow p-4">
                        <h3 class="font-semibold text-gray-800">Frequent Absentees (This Month)</h3>
                        <ul class="text-sm space-y-2">
                            <?php $__empty_1 = true; $__currentLoopData = $frequentAbsentees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><?php echo e($item->student->name ?? 'Student'); ?> — <?php echo e($item->total); ?> absences</li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-gray-500 text-sm">No students exceeded the absence limit.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="bg-white rounded-lg shadow p-4">
                        <h3 class="font-semibold text-gray-800">Recent Weekly Exams</h3>
                        <ul class="text-sm space-y-2">
                            <?php $__empty_1 = true; $__currentLoopData = $recentExamMarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><?php echo e(optional($mark->exam_date)->format('d M')); ?> • <?php echo e($mark->student->name ?? 'Student'); ?> • <?php echo e(number_format(($mark->marks_obtained / max(1, $mark->max_marks)) * 100, 1)); ?>%</li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-gray-500 text-sm">No marks recorded recently.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-4">
                    <h3 class="font-semibold text-gray-800 mb-3">Student Alerts</h3>
                    <ul class="text-sm space-y-1">
                        <?php $__empty_1 = true; $__currentLoopData = $instructorStudentAlerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><?php echo e($student->name); ?> — outstanding dues detected</li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="text-gray-500 text-sm">No alerts at the moment.</li>
                        <?php endif; ?>
                    </ul>
                </div>

                <div class="bg-white rounded-lg shadow p-4">
                    <h3 class="font-semibold text-gray-800 mb-3">Quick Actions</h3>
                    <div class="flex flex-wrap gap-3">
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('attendance.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('attendance.index')).'\'']); ?>Record Attendance <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('weekly-exams.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('weekly-exams.index')).'\'']); ?>Add Weekly Marks <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('reports.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('reports.index')).'\'']); ?>Download Student Report <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'window.location=\''.e(route('notes.index')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location=\''.e(route('notes.index')).'\'']); ?>Absence Notes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\project\codex\limit 2\resources\views/dashboard.blade.php ENDPATH**/ ?>