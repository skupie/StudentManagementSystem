<?php

namespace App\Livewire\Fees;

use App\Models\FeeInvoice;
use App\Models\FeePayment;
use App\Models\AuditLog;
use App\Models\Student;
use App\Support\AcademyOptions;
use App\Support\HandlesAutoDueInvoices;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Livewire\Component;
use Livewire\WithPagination;

class FeeManager extends Component
{
    use WithPagination;
    use HandlesAutoDueInvoices;

    public string $filterClass = 'all';
    public string $filterSection = 'all';
    public string $filterStatus = 'pending';
    public string $filterMonth = '';
    public string $invoiceStudentSearch = '';

    public array $invoiceForm = [
        'student_id' => '',
        'billing_month' => '',
        'amount_due' => '',
        'due_date' => '',
        'notes' => '',
    ];
    public ?int $editingInvoiceId = null;

    public array $paymentForm = [
        'fee_invoice_id' => '',
        'amount' => '',
        'payment_date' => '',
        'payment_mode' => '',
        'reference' => '',
        'receipt_number' => '',
        'scholarship_amount' => '',
    ];

    public string $recentSearch = '';

    public ?int $payingInvoiceId = null;
    public ?int $editingPaymentId = null;
    public bool $showPaymentLogModal = false;
    public array $paymentLog = [];

    protected function rules(): array
    {
        return [
            'invoiceForm.student_id' => ['required', 'exists:students,id'],
            'invoiceForm.billing_month' => ['required', 'date'],
            'invoiceForm.amount_due' => ['required', 'numeric', 'min:0'],
            'invoiceForm.due_date' => ['nullable', 'date'],
            'invoiceForm.notes' => ['nullable', 'string'],
            'paymentForm.fee_invoice_id' => ['nullable', 'exists:fee_invoices,id'],
            'paymentForm.amount' => ['nullable', 'numeric', 'min:0'],
            'paymentForm.payment_date' => ['nullable', 'date'],
            'paymentForm.payment_mode' => ['nullable', 'string', 'max:50'],
            'paymentForm.reference' => ['nullable', 'string', 'max:100'],
            'paymentForm.receipt_number' => ['nullable', 'string', 'max:100'],
            'paymentForm.scholarship_amount' => ['nullable', 'numeric', 'min:0'],
        ];
    }

    public function mount(): void
    {
        $this->invoiceForm['billing_month'] = now()->format('Y-m-01');
        $this->invoiceForm['due_date'] = now()->endOfMonth()->format('Y-m-d');
        $this->paymentForm['payment_date'] = now()->format('Y-m-d');
    }

    public function render()
    {
        $students = Student::query()
            ->when($this->invoiceStudentSearch, fn ($q) => $q->where('name', 'like', '%' . $this->invoiceStudentSearch . '%'))
            ->orderBy('name')
            ->get();

        $recentPayments = FeePayment::with(['student', 'invoice.student'])
            ->when($this->recentSearch, function ($q) {
                $q->where(function ($sub) {
                    $sub->whereHas('student', fn ($s) => $s->where('name', 'like', '%' . $this->recentSearch . '%'))
                        ->orWhere('receipt_number', 'like', '%' . $this->recentSearch . '%');
                });
            })
            ->latest('payment_date')
            ->latest('id')
            ->paginate(10, ['*'], 'paymentsPage');

        $invoices = FeeInvoice::query()
            ->with('student')
            ->when($this->filterClass !== 'all', fn ($q) => $q->whereHas('student', fn ($sub) => $sub->where('class_level', $this->filterClass)))
            ->when($this->filterSection !== 'all', fn ($q) => $q->whereHas('student', fn ($sub) => $sub->where('section', $this->filterSection)))
            ->when($this->filterStatus !== 'all', fn ($q) => $q->where('status', $this->filterStatus))
            ->when($this->invoiceStudentSearch, fn ($q) => $q->whereHas('student', function ($sub) {
                $sub->where('name', 'like', '%' . $this->invoiceStudentSearch . '%')
                    ->orWhere('phone_number', 'like', '%' . $this->invoiceStudentSearch . '%');
            }))
            ->when($this->filterMonth, fn ($q) => $q->whereRaw("DATE_FORMAT(billing_month, '%Y-%m') = ?", [$this->filterMonth]))
            ->latest('billing_month')
            ->paginate(10);

        $selectedInvoice = null;
        if ($this->paymentForm['fee_invoice_id']) {
            $selectedInvoice = FeeInvoice::with('student')->find($this->paymentForm['fee_invoice_id']);
        }

        $totalDue = 0;
        Student::chunkById(200, function ($students) use (&$totalDue) {
            foreach ($students as $student) {
                $totalDue += $student->dueSummary()['amount'];
            }
        });

        $totals = [
            'due' => $totalDue,
            'collected' => FeePayment::sum('amount'),
        ];

        return view('livewire.fees.fee-manager', [
            'students' => $students,
            'invoices' => $invoices,
            'classOptions' => ['all' => 'All Classes'] + AcademyOptions::classes(),
            'sectionOptions' => ['all' => 'All Sections'] + AcademyOptions::sections(),
            'paymentModes' => AcademyOptions::paymentModes(),
            'totals' => $totals,
            'recentPayments' => $recentPayments,
            'selectedInvoice' => $selectedInvoice,
        ]);
    }

    public function updatedInvoiceStudentSearch(): void
    {
        $this->resetPage();
    }

    public function updatedFilterClass(): void
    {
        $this->resetPage();
    }

    public function updatedFilterSection(): void
    {
        $this->resetPage();
    }

    public function updatedFilterStatus(): void
    {
        $this->resetPage();
    }

    public function updatedFilterMonth(): void
    {
        $this->resetPage();
    }

    public function updatedRecentSearch(): void
    {
        $this->resetPage('paymentsPage');
    }

    public function createInvoice(): void
    {
        $data = $this->validate([
            'invoiceForm.student_id' => ['required', 'exists:students,id'],
            'invoiceForm.billing_month' => ['required', 'date'],
            'invoiceForm.amount_due' => ['required', 'numeric', 'min:0'],
            'invoiceForm.due_date' => ['nullable', 'date'],
            'invoiceForm.notes' => ['nullable', 'string'],
        ])['invoiceForm'];

        $month = Carbon::parse($data['billing_month'])->startOfMonth();
        $baseAmount = round((float) $data['amount_due'], 2);

        if ($this->editingInvoiceId) {
            $invoice = FeeInvoice::findOrFail($this->editingInvoiceId);
            $previousAmount = (float) $invoice->amount_due;
            $invoice->update([
                'student_id' => $data['student_id'],
                'billing_month' => $month,
                'due_date' => $data['due_date'],
                'amount_due' => $baseAmount,
                'scholarship_amount' => 0,
                'was_active' => true,
                'manual_override' => true,
                'notes' => $data['notes'],
                'status' => 'pending',
            ]);
            $invoice->amount_paid = min($invoice->amount_paid ?? 0, $invoice->amount_due);
            $invoice->status = $invoice->amount_paid >= $invoice->amount_due
                ? 'paid'
                : ($invoice->amount_paid > 0 ? 'partial' : 'pending');
            $invoice->save();

            AuditLog::record(
                'invoice.update',
                'Invoice updated for ' . optional($invoice->student)->name . ' (' . $month->format('M Y') . ')',
                $invoice,
                [
                    'student_id' => $invoice->student_id,
                    'billing_month' => $month->toDateString(),
                    'previous_amount_due' => $previousAmount,
                    'amount_due' => $invoice->amount_due,
                    'notes' => $invoice->notes,
                ]
            );
        } else {
            $invoice = FeeInvoice::updateOrCreate(
                [
                    'student_id' => $data['student_id'],
                    'billing_month' => $month,
                ],
                [
                    'due_date' => $data['due_date'],
                    'amount_due' => $baseAmount,
                    'scholarship_amount' => 0,
                    'was_active' => true,
                    'manual_override' => true,
                    'notes' => $data['notes'],
                    'amount_paid' => 0,
                    'status' => 'pending',
                ]
            );

            AuditLog::record(
                'invoice.create',
                'Invoice created for ' . optional($invoice->student)->name . ' (' . $month->format('M Y') . ')',
                $invoice,
                [
                    'student_id' => $invoice->student_id,
                    'billing_month' => $month->toDateString(),
                    'amount_due' => $invoice->amount_due,
                    'notes' => $invoice->notes,
                ]
            );
        }

        $this->resetInvoiceForm($invoice->student_id);
        $this->resetPage();
    }

    public function editInvoice(int $invoiceId): void
    {
        $invoice = FeeInvoice::findOrFail($invoiceId);
        $this->editingInvoiceId = $invoice->id;
        $this->invoiceForm = [
            'student_id' => (string) $invoice->student_id,
            'billing_month' => Carbon::parse($invoice->billing_month)->format('Y-m-d'),
            'amount_due' => $invoice->gross_amount,
            'due_date' => optional($invoice->due_date)->format('Y-m-d'),
            'notes' => $invoice->notes,
        ];
    }

    public function cancelInvoiceEdit(): void
    {
        $this->resetInvoiceForm();
    }

    public function preparePayment(int $invoiceId): void
    {
        $invoice = FeeInvoice::findOrFail($invoiceId);
        $this->editingPaymentId = null;
        $this->payingInvoiceId = $invoice->id;
        $this->paymentForm = [
            'fee_invoice_id' => $invoice->id,
            'amount' => max(0, $invoice->amount_due - $invoice->amount_paid),
            'payment_date' => now()->format('Y-m-d'),
            'payment_mode' => $invoice->payment_mode_last,
            'reference' => '',
            'receipt_number' => '',
            'scholarship_amount' => $invoice->scholarship_amount,
        ];
    }

    public function savePayment(): void
    {
        if (! $this->paymentForm['fee_invoice_id']) {
            return;
        }

        $this->validate([
            'paymentForm.fee_invoice_id' => ['required', 'exists:fee_invoices,id'],
            'paymentForm.amount' => ['required', 'numeric', 'min:0'],
            'paymentForm.payment_date' => ['required', 'date'],
            'paymentForm.payment_mode' => ['nullable', 'string', 'max:50'],
            'paymentForm.reference' => ['nullable', 'string', 'max:100'],
            'paymentForm.receipt_number' => ['required', 'string', 'max:100'],
            'paymentForm.scholarship_amount' => ['nullable', 'numeric', 'min:0'],
        ]);

        DB::transaction(function () {
            $targetInvoice = FeeInvoice::lockForUpdate()->findOrFail($this->paymentForm['fee_invoice_id']);
            $baseAmount = (float) $targetInvoice->gross_amount;
            $scholarship = round((float) ($this->paymentForm['scholarship_amount'] ?? 0), 2);
            $paymentAmount = round((float) ($this->paymentForm['amount'] ?? 0), 2);
            $shouldRecordPayment = $paymentAmount > 0 || $scholarship > 0;

            if ($scholarship > $baseAmount) {
                throw ValidationException::withMessages([
                    'paymentForm.scholarship_amount' => 'Scholarship cannot exceed the month amount.',
                ]);
            }

            $previousInvoiceScholarship = $targetInvoice->scholarship_amount;

            $targetInvoice->scholarship_amount = $scholarship;
            $targetInvoice->amount_due = round(max(0, $baseAmount - $scholarship), 2);
            $targetInvoice->save();

            if ($targetInvoice->amount_due > 0 && $paymentAmount < 0.01) {
                throw ValidationException::withMessages([
                    'paymentForm.amount' => 'Provide at least ৳0.01 when there is an outstanding balance.',
                ]);
            }

            if ($this->editingPaymentId) {
                $payment = FeePayment::lockForUpdate()->findOrFail($this->editingPaymentId);
                $previousInvoice = FeeInvoice::lockForUpdate()->findOrFail($payment->fee_invoice_id);
                $previousAmount = $payment->amount;
                $previousScholarship = $previousInvoiceScholarship;

                $payment->update([
                    'fee_invoice_id' => $targetInvoice->id,
                    'student_id' => $targetInvoice->student_id,
                    'amount' => $paymentAmount,
                    'previous_amount' => $previousAmount,
                    'previous_scholarship_amount' => $previousScholarship,
                    'payment_date' => $this->paymentForm['payment_date'],
                    'payment_mode' => $this->paymentForm['payment_mode'],
                    'reference' => $this->paymentForm['reference'],
                    'receipt_number' => $this->paymentForm['receipt_number'],
                ]);

                $this->refreshInvoicePaymentSummary($previousInvoice);
                $this->refreshInvoicePaymentSummary($targetInvoice);
                $this->syncDueInvoiceForPartial($previousInvoice);
                $this->syncDueInvoiceForPartial($targetInvoice);

                AuditLog::record(
                    'payment.update',
                    'Payment updated for ' . optional($targetInvoice->student)->name . ' (' . $targetInvoice->billing_month?->format('M Y') . ')',
                    $payment,
                    [
                        'payment_id' => $payment->id,
                        'invoice_id' => $targetInvoice->id,
                        'student_id' => $targetInvoice->student_id,
                        'amount' => $paymentAmount,
                        'previous_amount' => $previousAmount,
                        'scholarship' => $scholarship,
                        'previous_scholarship' => $previousScholarship,
                        'payment_date' => $this->paymentForm['payment_date'],
                        'payment_mode' => $this->paymentForm['payment_mode'],
                        'receipt_number' => $this->paymentForm['receipt_number'],
                    ]
                );
            } else {
                if ($shouldRecordPayment) {
                    $payment = FeePayment::create([
                        'fee_invoice_id' => $targetInvoice->id,
                        'student_id' => $targetInvoice->student_id,
                        'amount' => $paymentAmount,
                        'previous_amount' => null,
                        'previous_scholarship_amount' => null,
                        'payment_date' => $this->paymentForm['payment_date'],
                        'payment_mode' => $this->paymentForm['payment_mode'],
                        'reference' => $this->paymentForm['reference'],
                        'receipt_number' => $this->paymentForm['receipt_number'],
                        'recorded_by' => auth()->id(),
                    ]);

                    AuditLog::record(
                        'payment.create',
                        'Payment recorded for ' . optional($targetInvoice->student)->name . ' (' . $targetInvoice->billing_month?->format('M Y') . ')',
                        $payment,
                        [
                            'payment_id' => $payment->id,
                            'invoice_id' => $targetInvoice->id,
                            'student_id' => $targetInvoice->student_id,
                            'amount' => $paymentAmount,
                            'scholarship' => $scholarship,
                            'payment_date' => $this->paymentForm['payment_date'],
                            'payment_mode' => $this->paymentForm['payment_mode'],
                            'receipt_number' => $this->paymentForm['receipt_number'],
                        ]
                    );
                }

                $this->refreshInvoicePaymentSummary($targetInvoice);
                $this->syncDueInvoiceForPartial($targetInvoice);
            }
        });

        $this->editingPaymentId = null;
        $this->payingInvoiceId = null;
        $this->resetPaymentForm();
    }

    public function editPayment(int $paymentId): void
    {
        $payment = FeePayment::with('invoice')->findOrFail($paymentId);
        $this->editingPaymentId = $payment->id;
        $this->payingInvoiceId = $payment->fee_invoice_id;
        $this->paymentForm = [
            'fee_invoice_id' => (string) $payment->fee_invoice_id,
            'amount' => $payment->amount,
            'payment_date' => optional($payment->payment_date)->format('Y-m-d'),
            'payment_mode' => $payment->payment_mode,
            'reference' => $payment->reference,
            'receipt_number' => $payment->receipt_number,
            'scholarship_amount' => optional($payment->invoice)->scholarship_amount,
        ];
    }

    public function cancelPaymentEdit(): void
    {
        $this->editingPaymentId = null;
        $this->payingInvoiceId = null;
        $this->resetPaymentForm();
    }

    public function showPaymentLog(int $paymentId): void
    {
        $payment = FeePayment::with(['student', 'invoice'])->find($paymentId);
        if (! $payment) {
            return;
        }

        $this->paymentLog = [
            'student' => $payment->student?->name,
            'class' => $payment->student?->class_level,
            'section' => $payment->student?->section,
            'invoice_month' => optional($payment->invoice?->billing_month)?->format('M Y'),
            'amount' => $payment->amount,
            'previous_amount' => $payment->previous_amount,
            'payment_date' => optional($payment->payment_date)?->format('d M Y'),
            'payment_mode' => $payment->payment_mode,
            'receipt_number' => $payment->receipt_number,
            'reference' => $payment->reference,
            'scholarship' => optional($payment->invoice)?->scholarship_amount ?? 0,
            'previous_scholarship_amount' => $payment->previous_scholarship_amount,
            'base_amount' => optional($payment->invoice)?->gross_amount ?? 0,
            'created_at' => optional($payment->created_at)?->format('d M Y, h:i A'),
            'updated_at' => optional($payment->updated_at)?->format('d M Y, h:i A'),
            'edited' => $payment->updated_at && $payment->created_at && $payment->updated_at->gt($payment->created_at),
        ];

        $this->showPaymentLogModal = true;
    }

    public function closePaymentLog(): void
    {
        $this->showPaymentLogModal = false;
        $this->paymentLog = [];
    }

    protected function resetInvoiceForm(?int $studentId = null): void
    {
        $this->editingInvoiceId = null;
        $this->invoiceForm = [
            'student_id' => $studentId ? (string) $studentId : '',
            'billing_month' => now()->format('Y-m-01'),
            'amount_due' => '',
            'due_date' => now()->endOfMonth()->format('Y-m-d'),
            'notes' => '',
        ];
    }

    protected function resetPaymentForm(): void
    {
        $this->paymentForm = [
            'fee_invoice_id' => '',
            'amount' => '',
            'payment_date' => now()->format('Y-m-d'),
            'payment_mode' => '',
            'reference' => '',
            'receipt_number' => '',
            'scholarship_amount' => '',
        ];
    }
}
