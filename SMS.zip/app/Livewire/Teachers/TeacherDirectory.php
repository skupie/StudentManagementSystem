<?php

namespace App\Livewire\Teachers;

use App\Models\Teacher;
use App\Support\AcademyOptions;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class TeacherDirectory extends Component
{
    use WithPagination;
    use WithFileUploads;

    public string $search = '';
    public string $statusFilter = 'all';
    public ?int $editingId = null;
    public $importFile;
    public array $form = [
        'name' => '',
        'subject' => '',
        'subjects' => [],
        'payment' => '',
        'contact_number' => '',
        'is_active' => true,
        'note' => '',
        'available_days' => [],
    ];

    public function render()
    {
        $dayOptions = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
        $subjectOptions = $this->subjectOptions();

        $teachers = Teacher::query()
            ->when($this->statusFilter !== 'all', function ($query) {
                $query->where('is_active', $this->statusFilter === 'active');
            })
            ->when($this->search, function ($query) {
                $query->where(function ($sub) {
                    $sub->where('name', 'like', '%' . $this->search . '%')
                        ->orWhere('subject', 'like', '%' . $this->search . '%');
                });
            })
            ->orderByDesc('is_active')
            ->orderBy('name')
            ->paginate(10);

        $hidePayment = auth()->user()?->role === 'assistant';

        return view('livewire.teachers.teacher-directory', [
            'teachers' => $teachers,
            'hidePayment' => $hidePayment,
            'canCreate' => $this->canManage(),
            'dayOptions' => $dayOptions,
            'subjectOptions' => $subjectOptions,
        ]);
    }

    public function save(): void
    {
        $data = $this->validate([
            'form.name' => ['required', 'string', 'max:255'],
            'form.subject' => ['nullable', 'string', 'max:255'],
            'form.subjects' => ['array'],
            'form.subjects.*' => ['string'],
            'form.payment' => ['nullable', 'numeric', 'min:0'],
            'form.contact_number' => ['nullable', 'string', 'max:50'],
            'form.is_active' => ['required', 'boolean'],
            'form.note' => ['nullable', 'string'],
            'form.available_days' => ['array'],
            'form.available_days.*' => ['in:Saturday,Sunday,Monday,Tuesday,Wednesday,Thursday'],
        ])['form'];

        $subjects = array_values(array_filter($data['subjects'] ?? []));
        $primarySubject = $subjects[0] ?? ($data['subject'] ?? null);

        if ($this->editingId) {
            Teacher::whereKey($this->editingId)->update([
                'name' => $data['name'],
                'subject' => $primarySubject,
                'subjects' => $subjects,
                'payment' => $data['payment'] ?: null,
                'contact_number' => $data['contact_number'],
                'is_active' => (bool) $data['is_active'],
                'note' => $data['note'],
                'available_days' => array_values($data['available_days'] ?? []),
            ]);
        } else {
            Teacher::create([
                'name' => $data['name'],
                'subject' => $primarySubject,
                'subjects' => $subjects,
                'payment' => $data['payment'] ?: null,
                'contact_number' => $data['contact_number'],
                'is_active' => (bool) $data['is_active'],
                'note' => $data['note'],
                'created_by' => auth()->id(),
                'available_days' => array_values($data['available_days'] ?? []),
            ]);
        }

        $this->resetForm();
        $this->resetPage();
        $this->dispatch('notify', message: 'Teacher saved.');
    }

    protected function canManage(): bool
    {
        return in_array(auth()->user()?->role, ['admin', 'instructor'], true);
    }

    public function resetForm(): void
    {
        $this->editingId = null;
        $this->form = [
            'name' => '',
            'subject' => '',
            'subjects' => [],
            'payment' => '',
            'contact_number' => '',
            'is_active' => true,
            'note' => '',
            'available_days' => [],
        ];
    }

    public function exportCsv()
    {
        $this->authorizeManage();

        $filename = 'teachers-' . now()->format('Ymd-His') . '.csv';
        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        $callback = function () {
            $handle = fopen('php://output', 'w');
            fprintf($handle, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM for Excel
            fputcsv($handle, ['name', 'subjects', 'payment', 'contact_number', 'is_active', 'note', 'available_days']);

            Teacher::orderBy('name')->chunk(200, function ($chunk) use ($handle) {
                foreach ($chunk as $teacher) {
                    fputcsv($handle, [
                        $teacher->name,
                        implode(',', (array) ($teacher->subjects ?? ($teacher->subject ? [$teacher->subject] : []))),
                        $teacher->payment ?? '',
                        $teacher->contact_number ?? '',
                        $teacher->is_active ? '1' : '0',
                        $teacher->note ?? '',
                        implode(',', (array) ($teacher->available_days ?? [])),
                    ]);
                }
            });

            fclose($handle);
        };

        return response()->streamDownload($callback, $filename, $headers);
    }

    public function importCsv(): void
    {
        $this->authorizeManage();

        $this->validate([
            'importFile' => ['required', 'file', 'mimes:csv,txt'],
        ]);

        // Store a copy to ensure readability across environments (esp. Windows).
        $tempStored = $this->importFile->store('imports');
        $handle = $tempStored ? Storage::readStream($tempStored) : false;
        if (! $handle) {
            $this->addError('importFile', 'Unable to open uploaded file.');
            if ($tempStored) {
                Storage::delete($tempStored);
            }
            return;
        }

        $header = fgetcsv($handle);
        if ($header && isset($header[0])) {
            $header[0] = ltrim($header[0], "\xEF\xBB\xBF"); // strip BOM
        }
        $header = $header ? array_map('strtolower', $header) : [];
        $expected = ['name', 'subjects', 'payment', 'contact_number', 'is_active', 'note', 'available_days'];
        $hasHeader = count(array_intersect($header, $expected)) >= 2;

        $imported = 0;
        while (($row = fgetcsv($handle)) !== false) {
            $record = [];
            if ($hasHeader) {
                foreach ($header as $index => $key) {
                    if (isset($row[$index])) {
                        $record[$key] = $row[$index];
                    }
                }
            } else {
                $record = array_combine($expected, array_pad($row, count($expected), null));
            }

            $name = trim($record['name'] ?? '');
            if ($name === '') {
                continue;
            }

            $subjects = array_values(array_filter(array_map('trim', explode(',', $record['subjects'] ?? ''))));
            $payment = is_numeric($record['payment'] ?? null) ? (float) $record['payment'] : null;
            $contact = trim($record['contact_number'] ?? '');
            $isActiveRaw = strtolower(trim($record['is_active'] ?? '1'));
            $isActive = in_array($isActiveRaw, ['1', 'true', 'yes', 'active'], true);
            $note = trim($record['note'] ?? '');
            $availableDays = array_values(array_filter(array_map('trim', explode(',', $record['available_days'] ?? ''))));
            $primarySubject = $subjects[0] ?? null;

            Teacher::updateOrCreate(
                ['name' => $name],
                [
                    'subject' => $primarySubject,
                    'subjects' => $subjects,
                    'payment' => $payment,
                    'contact_number' => $contact ?: null,
                    'is_active' => $isActive,
                    'note' => $note ?: null,
                    'available_days' => $availableDays,
                    'created_by' => auth()->id(),
                ]
            );
            $imported++;
        }

        fclose($handle);
        if ($tempStored) {
            Storage::delete($tempStored);
        }

        $this->importFile = null;
        $this->resetPage();
        if ($imported === 0) {
            $this->addError('importFile', 'No rows were imported. Please check the file headers and data.');
        } else {
            $this->dispatch('notify', message: "Import complete. {$imported} teacher(s) processed.");
        }
    }

    protected function authorizeManage(): void
    {
        if (! $this->canManage()) {
            abort(403);
        }
    }

    public function edit(int $teacherId): void
    {
        if (! $this->canManage()) {
            return;
        }

        $teacher = Teacher::find($teacherId);
        if (! $teacher) {
            return;
        }

        $this->editingId = $teacher->id;
        $this->form = [
            'name' => $teacher->name,
            'subject' => $teacher->subject ?? '',
            'subjects' => $teacher->subjects ?? [],
            'payment' => $teacher->payment ?? '',
            'contact_number' => $teacher->contact_number ?? '',
            'is_active' => (bool) $teacher->is_active,
            'note' => $teacher->note ?? '',
            'available_days' => $teacher->available_days ?? [],
        ];
    }

    protected function subjectOptions(): array
    {
        $subjects = [];
        $common = AcademyOptions::subjectsForSection('science');
        foreach (AcademyOptions::subjects() ?? [] as $key => $label) {
            $subjects[$key] = $label;
        }
        foreach (AcademyOptions::classes() as $classKey => $label) {
            $byClass = AcademyOptions::subjectsForSection($classKey) ?? [];
            foreach ($byClass as $key => $subjectLabel) {
                $subjects[$key] = $subjectLabel;
            }
        }
        foreach (AcademyOptions::sections() as $sectionKey => $label) {
            $bySection = AcademyOptions::subjectsForSection($sectionKey) ?? [];
            foreach ($bySection as $key => $subjectLabel) {
                $subjects[$key] = $subjectLabel;
            }
        }
        $subjects = array_merge($subjects, $common);
        return collect($subjects)->filter()->unique()->toArray();
    }
}
