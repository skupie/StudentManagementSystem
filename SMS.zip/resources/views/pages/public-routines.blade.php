<x-guest-layout>
    <div class="max-w-6xl mx-auto py-8 px-4 space-y-6">
      
        @livewire('routines.routine-viewer')
    </div>
</x-guest-layout>
